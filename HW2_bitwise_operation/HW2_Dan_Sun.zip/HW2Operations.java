/**
 * CS 2110 Fall 2014 HW2
 * Part 2 - Coding with bitwise operators
 * @author Dan Sun
 * 
 * *** NOTE: The rules are different for each java file! ***
 * 
 * The only things you are allowed to use in your code are the following:
 *	   - The bitwise operators |, &, ~, ^, <<, >>
 *     - Increment and Decrement (++ and --).
 *         - You may also add or subtract 1 from a number, but it must be only 1.
 *     - Boolean operators ||, &&, and !, which are only allowed in if-statements.
 *     - Conditional statements: if, if-else, switch-case, ? :
 *         - However, you may only handle up to two cases, or 2 conditionals. This means ternaries, too!
 *     - Equality comparisons (==, !=, <=, >=, <, >).
 *
 * You are not allowed to use anything not mentioned above. This includes the following,
 * but is not an exhaustive list:
 *     - Multiplication or Division
 *     - Addition or Subtraction with numbers other than 1.
 *          - Iteration in functions other than toString.
 *          - The unsigned right shift operator >>> (C does not provide this operator).
 *     - Modulus (%).
 *     - Any functions found in Java libraries (especially the Math library).
 *         - Example: Math.pow, Integer.bitCount, etc.
 *     - Casting (you should not have cast anywhere!)
 *          - Any Java 7 feature / standard library function.
 *            (we will be grading using Java 6)
 *      
 *     - Switch-case ban, you may not use more than 2 if-statements, or two
 *       case-statements using switch. (see the next point)
 *
 * Finally, your code must be robust and concise. If we asked you to print out the values 1 through 100
 * and you wrote 100 separate print statements, then sure, it works, but no one's gonna hire a coder who does
 * that. Likewise, you will NOT get credit for verbose answers for which there is a much more concise
 * solution. For instance, if you need to shift a value by n*4 times, you may not write x << n << n << n << n
 * or you will get no credit, because there is a much more concise way to do this in one operation by
 * shifting n. Keep this in mind, ESPECIALLY in the first 2 functions in this file.
 *
 * Remember that for this assignment, All bit masks must be written in hexadecimal.
 * This is the convention for masks and makes it much easier for the programmer to
 * understand the code. If you write a mask in any other base you will lose points.
 *
 * All of these functions accept ints as parameters because if you pass in a number
 * (which is of type int by default) into a function accepting a byte, then the Java
 * compiler will complain even if the number would fit into that type.
 *    
 * Now, keep in mind the return value is also an int. Please read the comments about how
 * many significant bits to return and make sure that the other bits are not set or else
 * you will not get any points for that test case.
 * i.e if I say to return 6 bits and you return 0xFFFFFFFF, you will lose points.
 *
 * Definitions of types:
 * nibble - 4 bits
 * byte   - 8 bits
 * short  - 16 bits
 * int    - 32 bits
 */
public class HW2Operations
{
	/**
	 * Set an 8-bit byte in an int.
	 * 
	 * Ints are made of four bytes, numbered like so:
	 *   B3 B2 B1 B0
	 *
	 * For a graphical representation of the bits:
	 *   3322222222221111111111
	 *   10987654321098765432109876543210 <= starting with bit 0
	 *   -------+-------+-------+-------+
	 *    Byte 3| Byte 2| Byte 1| Byte 0|
     *
	 * Examples:
	 *     setByte(0xAAA5BBC6, 0x17, 1); // => 0xAAA517C6
	 *     setByte(0x56B218F9, 0x44, 3); // => 0x44B218F9
	 *
	 * Note: Remember, no multiplication allowed!
	 * 
	 * @param num The int that will be modified.
	 * @param byte The byte to insert into the integer.
	 * @param which Selects which byte to modify - 0 for least-significant byte.
	 *            
	 * @return The modified int.
	 */
	public static int setByte(int num, int a_byte, int which)
	{
		// set a specific byte to 0
		which = which << 3;
		int mask = ~(0x000000FF << which);
		a_byte = a_byte << which;
		int maskedNum = num & mask;
		// insert a byte
		return (maskedNum | a_byte);
	}
	
	/**
	 * Get a 4-bit nibble from an int.
	 *
	 * Ints are made of 8 nibbles, numbered like so:
	 *   N7 N6 N5 N4 N3 N2 N1 N0
	 *
	 * For a graphical representation of the bits:
	 *   3322222222221111111111
	 *   10987654321098765432109876543210 <= starting with bit 0
	 *   ---+---+---+---+---+---+---+---+
	 *    N7| N6| N5| N4| N3| N2| N1| N0|
	 *
	 * Examples: 
	 *     getNibble(0x56781234, 3); // => 0x1
	 *     getNibble(0xFF254545, 7); // => 0xF
	 * 
     * Note: Remember, no multiplication allowed!
     *
	 * @param num The int to get a nibble from.
	 * @param which Determines which nibble gets returned - 0 for least-significant nibble.
	 *            
	 * @return A nibble corresponding to the "which" parameter from num.
	 */
	public static int getNibble(int num, int which)
	{
		// set other other nibbles to 0
		which = which << 2;
		int mask = (0x0000000F << which);
		int maskedNum = mask & num;
		// shift the nibble to the least significant position
		return (maskedNum >> which);
	}

	/**
	 * Pack 4 bytes into an int.
	 * 
	 * The bytes should be placed consecutively in the 32-bit int in the order
	 * specified by the parameters.
	 * 
	 * Example:
	 *     pack(0x12, 0x34, 0x56, 0x78); // => 0x12345678
	 *     pack(0xDE, 0xAD, 0xBE, 0xEF); // => 0xDEADBEEF
	 * 
	 * @param b3 Most significant byte (will always be an 8-bit number).
	 * @param b2 2nd byte (will always be an 8-bit number).
	 * @param b1 3rd byte (will always be an 8-bit number).
	 * @param b0 Least significant byte (will always be an 8-bit number).
	 *            
	 * @return a 32-bit value formatted like so: b3b2b1b0
	 */
	public static int pack(int b3, int b2, int b1, int b0)
	{
		// shift the most significant byte by 3*8 bits
		b3 = b3 << (3 << 3);
		// shift the 2nd significant byte by 2*8 bits
		b2 = b2 << (2 << 3);
		// shift the 3rd significant byte by 1*8 bits
		b1 = b1 << (1 << 3);
		// the least significant byte does not need shift
		// use '|' to pack bytes
		return b3 | b2 | b1 | b0;
	}
	
	/**
	 * Take the absolute value of an n-bit number.
	 * 
	 * Examples:
	 *     abs(0x00001234, 16); // => 0x00001234
	 *     abs(0x00001234, 13); // => 0x00000DCC
	 * 
	 * Note: We will only pass in values 1 to 31 for n.
	 * 
	 * @param num An n-bit 2's complement number.
	 * @param n The bit length of the number.
	 * @return The n-bit absolute value of num.
	 */
	public static int abs(int num, int n)
	{
		// get the sign of the number
		int sign = num >> n - 1;
		if (sign == 0) {
			return num; // return the original number, if the sign is 0
		} else {
			// if the sign is 1, ~X+1
			int mask = 0xFFFFFFFF << n;
			int absNum = ~(num | mask) + 1;
			return absNum;
		}
	}

	/**
	 * NOTE: For this method, you may only use &, |, and ~.
	 *
	 * Perform an exclusive-or on two 32-bit ints.
	 *
	 * Examples:
	 *     xor(0xFF00FF00, 0x00FF00FF); // => 0xFFFFFFFF
	 *     xor(0x12345678, 0x87654321); // => 0x95511559
	 * 
	 * @param num1 An int
	 * @param num2 Another int
	 *
	 * @return num1 ^ num2
	 */
	public static int xor(int num1, int num2)
	{
		// xor(x1,x2) = (x1|x2)&(~x1|~x2)
		return (num1 | num2) & (~num1 | ~num2);
	}
	
	/**
	 * Return true if the given number is a power of 2.
	 * 
	 * Examples:
	 *     powerOf2(1024); // => true
	 *     powerOf2(23);   // => false
	 *
	 * Note: Make sure you handle ALL the cases!
	 * Note2: Remember: Robust and concise! Do not just return an OR of all the powers of 2.
	 * 
	 * @param Num a 32-bit int. Since this is an int, it is SIGNED!
	 * @return true if num is a power of 2.
	 */
	public static boolean powerOf2(int num)
	{
		// return false for non-positive numbers
		if (num <= 0) {
			return false;
		}
		// return true for 1
		if (num == 1) {
			return true;
		}
		// return false for every odd number (except 1)
		int lastBin = num & 1;
		if (lastBin == 1) {
			return false;
		}
		// test if the even number is a power of 2
		int result =  (num - 1) & num; // if a number with n bits is a power of 2, minus one will result in (n-1) bits of 1
									   // & operator will give us a 0
		if (result == 0) {
			return true;
		} else {
			return false;
		}
	}
}
